﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace jromres._4EvProg.Dtos
{
    internal class ConsultasDto
    {
        ///Propiedades del objeto consultasdto valores por defecto para prueba
        string dniCompleto;
        string nombreUsuario;
        string apellido1;
        string apellido2;
        string especialidadUsuario;
        DateTime fechaCita = new DateTime(1999, 12, 31);
        bool asistenciaCita = false;

        ///contructores de referencia para dar de alta una nueva biblioteca
        public ConsultasDto()
        {
            
        }




        public ConsultasDto(string dniCompleto, string nombreUsuario, string apellido1, string apellido2,
                string especialidadUsuario, DateTime fechaCita, bool asistenciaCita)
        {
            

            this.dniCompleto = dniCompleto;
            this.nombreUsuario = nombreUsuario;
            this.apellido1 = apellido1;
            this.apellido2 = apellido2;
            this.especialidadUsuario = especialidadUsuario;
            this.fechaCita = fechaCita;
            this.asistenciaCita = asistenciaCita;
        }

        //Métodos de acceso getters y setters
        public string DniCompleto { get => dniCompleto; set => dniCompleto = value; }
        public string NombreUsuario { get => nombreUsuario; set => nombreUsuario = value; }
        public string Apellido1 { get => apellido1; set => apellido1 = value; }
        public string Apellido2 { get => apellido2; set => apellido2 = value; }
        public string EspecialidadUsuario { get => especialidadUsuario; set => especialidadUsuario = value; }
        public DateTime FechaCita { get => fechaCita; set => fechaCita = value; }
        public bool AsistenciaCita { get => asistenciaCita; set => asistenciaCita = value; }

        



        /// <summary>
        /// 
        /// metodo tstring para mostrar el nombre del usuario. fech y hora en fichero
        /// </summary>
        /// <returns>nombre y fecha</returns>
        public string ToString()
        {
            string consulta =
                $"Nombre: {NombreUsuario} \n" +
                $"Hora: {fechaCita.Hour}:{fechaCita.Minute.ToString("D2")}\n" +
                $"------------------------------";

            return consulta;
        }




    }
}
