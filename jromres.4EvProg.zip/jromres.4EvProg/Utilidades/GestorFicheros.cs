﻿using jromres._4EvProg.Controladores;
using jromres._4EvProg.Dtos;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jromres._4EvProg.Utilidades
{
    internal class GestorFicheros
    {   
        /// <summary>
        /// metodo estatico que accede al fichero y verifica si hay datos para mostrar al abrir la aplicacion 
        /// </summary>
        /// <param name="rutaFicheroGeneral"></param>
        public static void accesoAFicheros(string rutaFicheroGeneral)
        {
            if (File.Exists(rutaFicheroGeneral))
            {
                try
                {
                    string[] contenidoFichero = File.ReadAllLines(rutaFicheroGeneral);

                    foreach (string fichero in contenidoFichero)
                    {
                        string[] partes = fichero.Split(';');
                        ConsultasDto consulta = new ConsultasDto(partes[0], partes[1],
                            partes[2], partes[3], partes[4], DateTime.ParseExact(partes[5],
                            "dd-MM-yyyy HH:mm:ss", CultureInfo.InvariantCulture),
                            bool.Parse(partes[6]));
                        Program.listaConsultas.Add(consulta);
                    }

                    Console.WriteLine("Lista de consultas");
                    foreach (string line in contenidoFichero)
                    {
                        Console.WriteLine(line);
                    }
                }
                catch (IOException e)
                {
                    Console.WriteLine("Error al leer el archivo: " + e.Message);
                }
            }
            else
            {
                Console.WriteLine("No existen consultas para mostrar");
            }
        }
        /// <summary>
        /// metodo que asigna el nombre del fichero log en funcion de la fecha 
        /// </summary>
        /// <returns>un string con el nombre del fuchero para emplearlo en el nombre de la ruta y concatenarlo</returns>
        
        public static string nombreFichero()
        {
            try
            {
                DateTime fechaActual = DateTime.Today;
                string diasFecha = fechaActual.ToString("dd");
                string mesFecha = fechaActual.ToString("MM");
                string anioFecha = fechaActual.ToString("yyyy");
                string fechaCompleta = diasFecha + mesFecha + anioFecha;
                string rutaArchivo = "C:\\Users\\frodriguezz\\Desktop\\jromres.4EvProg\\log-" + fechaCompleta + ".txt";
                return rutaArchivo;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// metodo estatico para sobreescribir en el fichero log y registrar las operaciones que realiza el usuario, se guarda la accion y la fecha 
        /// </summary>
        /// <param name="accion"></param>
        public static void SobreEscribir(string accion)
        {
            try
            {
                using (StreamWriter writer = new StreamWriter(nombreFichero(), true))
                {
                    writer.WriteLine(accion);
                }
            }
            catch (IOException e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }
        /// <summary>
        /// metodo estatico de creacion del fiuchero log
        /// </summary>
        public static void CreaFichero()
        {
            try
            {
                File.Create(nombreFichero()).Close();
            }
            catch (IOException e)
            {
                Console.WriteLine(e.StackTrace);
            }
        }
    }   
       
}
