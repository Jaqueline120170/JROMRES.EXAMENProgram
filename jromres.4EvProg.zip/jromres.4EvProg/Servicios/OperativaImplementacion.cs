﻿using jromres._4EvProg.Controladores;
using jromres._4EvProg.Dtos;
using jromres._4EvProg.Utilidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jromres._4EvProg.Servicios
{
    internal class OperativaImplementacion : OperativaInterfaz
    {
        public void mostrarConsultasDelDia(string especialidad)
        {
            try
            {
                GestorFicheros.SobreEscribir(DateTime.Now.ToString() + " Mostrar consultas del día");
                DateTime fechaSeleccionada = IntroducirFecha();
                bool encontrada = false;

                foreach (ConsultasDto consulta in Program.listaConsultas)
                {
                    DateTime citaDate = consulta.FechaCita.Date;
                    if (fechaSeleccionada.Date.Equals(citaDate))
                    {
                        if (consulta.EspecialidadUsuario.Equals(especialidad))
                        {
                            encontrada = true;
                            Console.WriteLine("Nombre completo: " + consulta.NombreUsuario + " " + consulta.Apellido1
                                + " " + consulta.Apellido2 + ", Hora: " + consulta.FechaCita.Hour + ":" + consulta.FechaCita.Minute.ToString("D2"));
                        }
                        
                    }
                }

                if (!encontrada)
                {
                    Console.WriteLine("No hay consultas registradas para la fecha y especialidad especificadas.");
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Metodo privado que solicita la fecha al usuario como un string y la convierte a la instancia de tiempo que se requiere
        /// para trabar con ella en otros metodos
        /// </summary>
        /// <returns>devuelve una fecha en formato datetime</returns>
        private DateTime IntroducirFecha()
        {
            Console.WriteLine("Elija una fecha (yyyy-MM-dd)");
            string fechaEscogida = Console.ReadLine();

            try
            {
                return DateTime.ParseExact(fechaEscogida, "yyyy-MM-dd", null);
            }
            catch (FormatException)
            {
                Console.WriteLine("Error: La fecha ingresada no es válida. Por favor, ingrese una fecha en formato yyyy-MM-dd.");
                return IntroducirFecha();
            }
        }

       
        /// <summary>
        /// metodo que muestra las citas con asistencia en la fecha y especialidad especificada
        /// </summary>
        /// <param name="fecha"></param>
        /// <param name="transformacion"></param>
        /// <returns>después de reocrrer la lista devuelve aquellas que hagan match con la fecha introducida</returns>
        private List<ConsultasDto> ObtenerCitasConAsistenciaEnFecha(DateTime fecha, string transformacion)
        {
            try
            {
                List<ConsultasDto> citasConAsistenciaEnFecha = new List<ConsultasDto>();

                foreach (ConsultasDto citaFichero in Program.listaConsultas)
                {
                    if (citaFichero.AsistenciaCita && citaFichero.FechaCita.Date.Equals(fecha.Date) && citaFichero.EspecialidadUsuario.Equals(transformacion))
                    {
                        citasConAsistenciaEnFecha.Add(citaFichero);
                    }
                }

                return citasConAsistenciaEnFecha;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public void ImprimirConsultasFichero()
        {
            //DateTime fechaActual = DateTime.Now;
            //string fechaFormateada = fechaActual.ToString("ddMMyyyy");
            try
            {

                MenuInterfaz mi = new MenuImplementacion();
                int seleccion = mi.mostrarMenuEspecialidades();
                string transformacion = pasarAEspecialidad(seleccion);

                DateTime fechaSeleccionada = IntroducirFecha();
                string fechaFormateada = fechaSeleccionada.ToString("ddMMyyyy");
                string ficheroAsistencia = "C:\\Users\\frodriguezz\\Desktop\\jromres.4EvProg\\citasConAsistencia-" + fechaFormateada + ".txt";
                List<ConsultasDto> citasEnFecha = ObtenerCitasConAsistenciaEnFecha(fechaSeleccionada, transformacion);

                if (citasEnFecha.Count > 0)
                {
                    using (StreamWriter sw = new StreamWriter(ficheroAsistencia))
                    {
                        foreach (ConsultasDto citaFichero in citasEnFecha)
                        {
                            string asistencia = citaFichero.ToString();
                            sw.WriteLine(asistencia);
                        }
                    }
                    Console.WriteLine("Se ha creado el archivo '" + ficheroAsistencia + "' correctamente.");
                }
                else
                {
                    Console.WriteLine("No hay asistencias para la fecha seleccionada.");
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// metodo privado para pasar la especialidad  seleccionada por el usuario y poder operar con ella
        /// </summary>
        /// <param name="seleccion"></param>
        /// <returns>devuelve un string que corresponde al nombre de la especialidad</returns>
        private string pasarAEspecialidad(int seleccion)
        {
            try
            {
                string especialidad = "";
                switch (seleccion)
                {
                    case 1:
                        especialidad = "Psicología";
                        break;
                    case 2:
                        especialidad = "Traumatología";
                        break;
                    case 3:
                        especialidad = "Fisioterapia";
                        break;
                }

                return especialidad;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

    }

}
