﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jromres._4EvProg.Servicios
{
    internal interface MenuInterfaz
    {
        /// <summary>
        /// metodo que muestra el menu principal al usuario
        /// </summary>
        /// <returns>Devuelve un entero que contiene la opcion seleccionada por el usuario</returns>
        public int menuPrincipal();
        /// <summary>
        /// medodo para seleccionar las opciones del submenu
        /// </summary>
        public void seleccionConsultas();

        /// <summary>
        /// metodo para mostrar las especialidades al usuario y hacer algo con esa seleccion
        /// </summary>
        public void seleccionEspecialidades();

        /// <summary>
        /// metodo que muestra y recoge las especialidad seleccionada por el usuario
        /// </summary>
        /// <returns></returns>
        public int mostrarMenuEspecialidades();
    }
}
