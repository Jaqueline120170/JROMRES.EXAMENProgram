﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jromres._4EvProg.Servicios
{
    internal interface RegistroInterfaz
    {
        /// <summary>
        /// metodo que solicita al usuario su dni para registrar su llegada , verifica si su dni coincide con alguno de los que hay en la lista 
        /// </summary>
        public void registroLlegada();
    }
}
