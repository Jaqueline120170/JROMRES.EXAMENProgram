﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jromres._4EvProg.Servicios
{
    internal interface OperativaInterfaz
    {
        /// <summary>
        /// busca a los pacientes que tengan cita en la fecha y especialidad especificada , si tiene cita imprime el nombre y hora , sino existe, aparece un mensaje que indica que no hay citas registradas para ese día
        /// </summary>
        /// <param name="especialidad"></param>
        public void mostrarConsultasDelDia(string especialidad);

        /// <summary>
        /// es un metodo que en funcion de la fecha, especialidad y asistencia imprime en un fichero los datos del paciente.
        /// </summary>
        public void ImprimirConsultasFichero();
    }
}
