﻿using jromres._4EvProg.Controladores;
using jromres._4EvProg.Dtos;
using jromres._4EvProg.Utilidades;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;

namespace jromres._4EvProg.Servicios
{
    internal class RegistroImplementacion : RegistroInterfaz
    {

        public void registroLlegada()
        {
            try
            {
                GestorFicheros.SobreEscribir(DateTime.Now.ToString() + " Registra una llegada");
                Console.WriteLine("REGISTRO DE LLEGADA");
                Console.WriteLine("--------------------");
                string dni = VerificarDNI();
                bool dniEncontrado = false;

                foreach (ConsultasDto buscarDni in Program.listaConsultas)
                {
                    if (buscarDni.DniCompleto.Equals(dni))
                    {
                        dniEncontrado = true;
                        Console.WriteLine("Espere su turno para la consulta de " + buscarDni.EspecialidadUsuario + " en la sala de espera. Su especialista le avisará.\r\n");
                    }
                }

                if (!dniEncontrado)
                {
                    Console.WriteLine("No dispone de cita previa hoy.");
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }


        /// <summary>
        /// metodo para verificar que el dni que el usuario ha ingresado es valido en funcion de una serie de verificaciones. 
        /// </summary>
        /// <returns>string </returns>
        private string VerificarDNI()
        {
            try
            {
                char[] letras = { 'T', 'R', 'W', 'A', 'G', 'M', 'Y', 'F', 'P', 'D', 'X', 'B', 'N', 'J', 'Z', 'S', 'Q', 'V', 'H', 'L', 'C', 'K', 'E' };
                char letra;
                string DNI = "";
                bool valido = false;
                do
                {
                    Console.WriteLine("Dame la letra de tu DNI (Ponlo en mayusculas)");
                    letra = Console.ReadLine().ToUpper()[0];
                    Console.WriteLine("Dame el numero de su DNI");
                    int numeroDNI = Convert.ToInt32(Console.ReadLine());

                    int resto = numeroDNI % 23;
                    if (letras[resto] == letra)
                    {
                        DNI = numeroDNI + "" + letra;
                        valido = true;
                    }
                    else
                    {
                        Console.WriteLine("DNI incorrecto, introduce uno válido.");
                    }
                } while (!valido);

                return DNI;
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }


}

