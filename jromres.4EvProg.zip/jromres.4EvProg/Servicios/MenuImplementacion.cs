﻿using jromres._4EvProg.Controladores;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace jromres._4EvProg.Servicios
{
    internal class MenuImplementacion : MenuInterfaz
    {
        OperativaInterfaz oi = new OperativaImplementacion();

        public int menuPrincipal()
        {
            try
            {

                Utilidades.GestorFicheros.SobreEscribir(DateTime.Now.ToString() + " Acceso a menú principal");

                int seleccionPrincipal;
                Console.WriteLine("ACCESO PRINCIPAL");
                Console.WriteLine("------------------");
                Console.WriteLine("0. Cerrar menu");
                Console.WriteLine("1. Registrar llegada");
                Console.WriteLine("2. Listado Consultas");
                Console.WriteLine("Seleccione una opción");
                seleccionPrincipal = Convert.ToInt32(Console.ReadLine());
                return seleccionPrincipal;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        /// <summary>
        /// Mètodo privado que muestra un submenu para tener acceso a la opcion de mostrar consultas por fecha y especialidad  o imprimir las citas con asistencia en un fichero
        /// </summary>
        /// <returns></returns>
        private int menuConsultas()
        {
            try
            {
                Utilidades.GestorFicheros.SobreEscribir(DateTime.Now.ToString() + " Acceso a menú consultas");

                int opcionConsultas;
                Console.WriteLine("----------------");
                Console.WriteLine("Listado Consultas");
                Console.WriteLine("----------------");
                Console.WriteLine("0. Volver");
                Console.WriteLine("1. Mostrar Consultas");
                Console.WriteLine("2. Imprimir Consultas");
                Console.WriteLine("Seleccione una opción");
                opcionConsultas = Convert.ToInt32(Console.ReadLine());
                return opcionConsultas;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public void seleccionConsultas()
        {
            try
            {
                int seleccionConsulta = menuConsultas();
                switch (seleccionConsulta)
                {
                    case 0:
                        break;
                    case 1:
                        seleccionEspecialidades();
                        break;
                    case 2:
                        oi.ImprimirConsultasFichero();
                        break;
                    default:
                        Console.WriteLine("Introduzca una opción válida");
                        break;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public int mostrarMenuEspecialidades()
        {
            try
            {
                Utilidades.GestorFicheros.SobreEscribir(DateTime.Now.ToString() + " Acceso a menú de especialidades");

                int opcionEspecialidades;
                Console.WriteLine("------------------------");
                Console.WriteLine("Listado Especialidades");
                Console.WriteLine("------------------------");
                Console.WriteLine("0. Volver");
                Console.WriteLine("1. Psicología");
                Console.WriteLine("2. Traumatología");
                Console.WriteLine("3. Fisioterapia");
                Console.WriteLine("Seleccione la opción de especialidad que desea mostrar:");
                opcionEspecialidades = Convert.ToInt32(Console.ReadLine());
                return opcionEspecialidades;
            }
            catch (Exception e)
            {
                throw e;
            }
        }

        public void seleccionEspecialidades()
        {
            try
            {
                int seleccionEspecialidades = mostrarMenuEspecialidades();
                switch (seleccionEspecialidades)
                {
                    case 0:
                        break;
                    case 1:
                        oi.mostrarConsultasDelDia("Psicología");
                        break;
                    case 2:
                        oi.mostrarConsultasDelDia("Traumatología");
                        break;
                    case 3:
                        oi.mostrarConsultasDelDia("Fisioterapia");
                        break;
                    default:
                        Console.WriteLine("Introduzca una opción válida");
                        break;
                }
            }
            catch (Exception e)
            {
                throw e;
            }
        }
    }

    
}

